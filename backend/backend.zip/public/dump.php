<?php
// Temp file deleted
