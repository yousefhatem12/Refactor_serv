<?php
// Removed helper
