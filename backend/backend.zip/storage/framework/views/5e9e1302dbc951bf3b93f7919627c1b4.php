<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('language-switch-component', []);

$__keyOuter = $__key ?? null;

$__key = 'fls-in-panels';
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-391635853-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?><?php /**PATH C:\xampp\htdocs\serv5-last-last\backend\storage\framework\views/0a5cc43e3ce9da56eefe6c41d9cb9d99.blade.php ENDPATH**/ ?>