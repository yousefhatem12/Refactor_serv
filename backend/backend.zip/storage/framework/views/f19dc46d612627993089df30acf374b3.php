<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\serv5-last-last\backend\vendor\filament\support\resources\views/components/dropdown/list/index.blade.php ENDPATH**/ ?>