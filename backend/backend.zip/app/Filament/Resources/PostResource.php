<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PostResource\Pages;
use App\Models\Post;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Section;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\RichEditor\ToolbarButtonGroup;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use App\Models\User;
use Filament\Forms\Components\Select;
use Illuminate\Support\Str;

class PostResource extends Resource
{
    protected static ?string $model = Post::class;
    protected static bool $shouldRegisterNavigation = false;
    public static function getNavigationGroup(): ?string { return __('Pages'); }
    protected static ?int $navigationSort = 4;
    protected static string|\BackedEnum|null $navigationIcon = 'heroicon-o-newspaper';
    public static function getNavigationLabel(): string { return __('Blog'); }

    public static function getModelLabel(): string
    {
        return __('Post');
    }

    public static function getPluralModelLabel(): string
    {
        return __('Posts');
    }

    public static function getRichEditorToolbarButtons(): array
    {
        return [
            ['bold', 'italic', 'underline', 'strike', 'subscript', 'superscript', 'link'],
            [
                ToolbarButtonGroup::make('Format', [
                    'paragraph',
                    'h2',
                    'h3',
                    'h4',
                    'h5',
                    'h6',
                ])->textualButtons(),
            ],
            ['alignStart', 'alignCenter', 'alignEnd'],
            ['blockquote', 'codeBlock', 'bulletList', 'orderedList'],
            ['table', 'attachFiles'],
            ['undo', 'redo'],
        ];
    }

    public static function form(Schema $schema): Schema
    {
        $isAr = app()->getLocale() === 'ar';
        return $schema
            ->components([
                Section::make($isAr ? 'تفاصيل المقال' : 'Post Details')
                    ->schema([
                        TextInput::make('title.en')
                            ->label($isAr ? 'العنوان (إنجليزي)' : 'Title (English)')
                            ->required()
                            ->live(onBlur: true)
                            ->afterStateUpdated(fn (string $operation, $state, $set) => $operation === 'create' ? $set('slug', Str::slug($state)) : null),
                        TextInput::make('title.ar')
                            ->label($isAr ? 'العنوان (عربي)' : 'Title (Arabic)')
                            ->required(),
                        TextInput::make('slug')
                            ->label($isAr ? 'الرابط الفرعي (Slug)' : 'Slug')
                            ->required()
                            ->unique(Post::class, 'slug', ignoreRecord: true),
                        RichEditor::make('content.en')
                            ->label($isAr ? 'المحتوى (إنجليزي)' : 'Content (English)')
                            ->required()
                            ->toolbarButtons(self::getRichEditorToolbarButtons())
                            ->columnSpanFull(),
                        RichEditor::make('content.ar')
                            ->label($isAr ? 'المحتوى (عربي)' : 'Content (Arabic)')
                            ->required()
                            ->toolbarButtons(self::getRichEditorToolbarButtons())
                            ->columnSpanFull(),
                        FileUpload::make('image')
                            ->label($isAr ? 'الصورة' : 'Image')
                            ->image()
                            ->directory('blog')
                            ->saveUploadedFileUsing(fn ($file) => \App\Services\ImageService::convertToWebp($file, 'blog')),
                        Select::make('blog_category_id')
                            ->label($isAr ? 'التصنيف' : 'Category')
                            ->options(fn () => \App\Models\BlogCategory::all()->mapWithKeys(fn ($item) => [
                                $item->id => $item->name[app()->getLocale()] ?? $item->name['en'] ?? ''
                            ]))
                            ->searchable()
                            ->required(),
                        Toggle::make('is_published')
                            ->label($isAr ? 'منشور' : 'Published')
                            ->default(false),
                        Toggle::make('is_trending')
                            ->label($isAr ? 'رائج (Trending)' : 'Trending')
                            ->default(false),
                        Select::make('author_id')
                            ->label($isAr ? 'الكاتب' : 'Author')
                            ->relationship('author', 'name')
                            ->default(\Illuminate\Support\Facades\Auth::id())
                            ->required()
                            ->searchable(),
                    ]),
                Section::make($isAr ? 'إعدادات السيو (SEO)' : 'SEO Settings')
                    ->schema([
                        TextInput::make('seo_title.en')
                            ->label($isAr ? 'عنوان السيو (إنجليزي)' : 'SEO Title (EN)')
                            ->nullable(),
                        TextInput::make('seo_title.ar')
                            ->label($isAr ? 'عنوان السيو (عربي)' : 'SEO Title (AR)')
                            ->nullable(),
                        \Filament\Forms\Components\Textarea::make('seo_description.en')
                            ->label($isAr ? 'وصف السيو (إنجليزي)' : 'Meta Description (EN)')
                            ->nullable(),
                        \Filament\Forms\Components\Textarea::make('seo_description.ar')
                            ->label($isAr ? 'وصف السيو (عربي)' : 'Meta Description (AR)')
                            ->nullable(),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        $isAr = app()->getLocale() === 'ar';
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('image')
                    ->label($isAr ? 'الصورة' : 'Image'),
                Tables\Columns\TextColumn::make($isAr ? 'title.ar' : 'title.en')
                    ->label($isAr ? 'العنوان' : 'Title')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('author.name')
                    ->label($isAr ? 'الكاتب' : 'Author')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('slug')
                    ->label($isAr ? 'الرابط (Slug)' : 'Slug')
                    ->searchable(),
                Tables\Columns\TextColumn::make('blogCategory.name')
                    ->label($isAr ? 'التصنيف' : 'Category')
                    ->badge()
                    ->getStateUsing(function ($record) use ($isAr) {
                        if ($record->blogCategory) {
                            $name = $record->blogCategory->name;
                            return is_array($name) ? ($name[app()->getLocale()] ?? $name['en'] ?? '') : $name;
                        }
                        $cat = $record->category;
                        if (!$cat) return '';
                        $map = [
                            'TECHNOLOGY' => $isAr ? 'تكنولوجيا' : 'Technology',
                            'WEB DEVELOPMENT' => $isAr ? 'تطوير الويب' : 'Web Development',
                            'STARTUP' => $isAr ? 'شركات ناشئة' : 'Startup',
                            'DROP SHIPPING' => $isAr ? 'دروب شيبنج' : 'Drop Shipping',
                            'HARDWARE' => $isAr ? 'عتاد هاردوير' : 'Hardware',
                            'SOFTWARE' => $isAr ? 'برمجيات' : 'Software',
                            'MARKETING' => $isAr ? 'تسويق' : 'Marketing',
                        ];
                        $key = strtoupper(trim($cat));
                        return $map[$key] ?? $cat;
                    })
                    ->sortable(),
                Tables\Columns\IconColumn::make('is_published')
                    ->label($isAr ? 'منشور' : 'Published')
                    ->boolean()
                    ->sortable(),
                Tables\Columns\IconColumn::make('is_trending')
                    ->label($isAr ? 'رائج (Trending)' : 'Trending')
                    ->boolean()
                    ->sortable(),
                Tables\Columns\IconColumn::make('seo_description')
                    ->label($isAr ? 'السيو (SEO)' : 'SEO')
                    ->getStateUsing(fn ($record) => !empty($record->seo_description['ar']) || !empty($record->seo_description['en']))
                    ->boolean()
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                \Filament\Actions\EditAction::make(),
                \Filament\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                \Filament\Actions\BulkActionGroup::make([
                    \Filament\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPosts::route('/'),
            'create' => Pages\CreatePost::route('/create'),
            'edit' => Pages\EditPost::route('/{record}/edit'),
        ];
    }
}
