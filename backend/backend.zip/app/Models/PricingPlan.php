<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PricingPlan extends Model
{
    protected $fillable = [
        'service_id',
        'name',
        'price',
        'currency',
        'period',
        'features',
        'is_popular',
        'is_active',
        'button_text',
        'button_url',
        'sort_order',
    ];

    protected $casts = [
        'service_id' => 'integer',
        'name' => 'array',
        'period' => 'array',
        'features' => 'array',
        'button_text' => 'array',
        'is_popular' => 'boolean',
        'is_active' => 'boolean',
        'sort_order' => 'integer',
    ];

    public function service(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Service::class);
    }

    protected static function booted()
    {
        $clear = function () {
            // Since cache keys for pricing plans include dynamic params, flush all caches to be safe
            \Illuminate\Support\Facades\Cache::flush();
        };
        static::saved($clear);
        static::deleted($clear);

        static::saving(function ($model) {
            if (empty($model->price)) {
                $model->price = '0';
            }
            if (empty($model->currency)) {
                $model->currency = '$';
            }
        });
    }
}
