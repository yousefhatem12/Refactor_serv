1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/1d4h-sglyo8ft.js","/_next/static/chunks/0vk3nqty20h_-.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/1d4h-sglyo8ft.js","/_next/static/chunks/0vk3nqty20h_-.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/1d4h-sglyo8ft.js","/_next/static/chunks/0vk3nqty20h_-.js"],"IconMark"]
6:[]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.2bd07y063drqh.ico","sizes":"32x24","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W6","buildId":"Nmo3JUFZdnIG4NZ32j6e2"}
